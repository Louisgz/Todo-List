$(function () {
  //* Création des constantes et des variables nécessaire

  const addBtn = document.querySelector(".new_Submit-btn");
  let tache = document.querySelector(".new_input");

  if (window.localStorage.getItem("todo") == undefined) {
    let todo = [];
    window.localStorage.setItem("todo", JSON.stringify(todo));
  }

  if (
    window.localStorage.getItem("doing") == "undefined" ||
    window.localStorage.getItem("doing") == undefined
  ) {
    let doing = [];
    window.localStorage.setItem("doing", JSON.stringify(doing));
  }

  if (window.localStorage.getItem("done") == undefined) {
    let done = [];
    window.localStorage.setItem("done", JSON.stringify(done));
  }

  var todoEX = window.localStorage.getItem("todo");
  var todo = JSON.parse(todoEX);

  var doingEX = window.localStorage.getItem("doing");
  var doing = JSON.parse(doingEX);

  var doneEX = window.localStorage.getItem("done");
  var done = JSON.parse(doneEX);

  //* Animation du bouton 'ajouter'

  $(".new_btn").click(function () {
    $(".new_btn").hide();
    $(".new").css({
      width: "300px",
    });
    $(".new_form").show();
    $(".new_form").css("display", "flex");
    $(".new_input").focus();
  });

  class item {
    constructor(itemName, Emplacement) {
      this.createItem(itemName, Emplacement);
    }

    //* Création de l'élément de la page qui sera la tâche

    createItem(itemName, Emplacement) {
      let list_item = document.createElement("div");
      list_item.classList.add("List_item");
      list_item.setAttribute("draggable", true);
      list_item.addEventListener("dragstart", this.dragstart_handler);
      list_item.id = uniqid();
      list_item.setAttribute("ondragstart", "dragstart_handler(event)");

      let list_item_left = document.createElement("div");
      list_item_left.classList.add("List_item_left");

      let list_item_name = document.createElement("input");
      list_item_name.value = itemName;
      list_item_name.disabled = true;

      list_item_left.appendChild(list_item_name);

      let list_item_right = document.createElement("div");
      list_item_right.classList.add("List_item_right");

      let fa_times = document.createElement("button");
      fa_times.classList.add("remove");
      let itime = document.createElement("i");
      itime.classList.add("fa", "fa-times");
      fa_times.appendChild(itime);

      let fa_pen = document.createElement("button");
      fa_pen.classList.add("modifier");
      let ipen = document.createElement("i");
      ipen.classList.add("fa", "fa-pen");
      fa_pen.appendChild(ipen);

      list_item_right.appendChild(fa_pen);
      list_item_right.appendChild(fa_times);

      var List_items;
      switch (Emplacement) {
        case "todo":
          var List_items = document.querySelector(".List_items_todo");
          break;
        case "doing":
          var List_items = document.querySelector(".List_items_doing");
          break;
        case "done":
          var List_items = document.querySelector(".List_items_done");
          break;
      }

      List_items.appendChild(list_item);
      list_item.appendChild(list_item_left);
      list_item.appendChild(list_item_right);

      // list_item_name.addEventListener("click", () => {
      //   this.edit(list_item_name, itemName, Emplacement);
      // });

      // fa_pen.addEventListener("click", () => {
      //   this.edit(list_item_name, itemName, Emplacement);
      // });

      // fa_times.addEventListener("click", () => {
      //   this.delete(list_item, itemName, Emplacement);
      // });
    }
  }

  //* Fonctions check qui sert à ajouter une tâ à la Todo List

  addBtn.addEventListener("click", check);

  function check() {
    if (tache.value != "") {
      new item(tache.value, "todo");
      todo.push(tache.value);
      window.localStorage.setItem("todo", JSON.stringify(todo));
      tache = "";
    }
  }

  //* Afficher les tâches

  for (var i = 0; i < todo.length; i++) {
    new item(todo[i], "todo");
  }
  for (var i = 0; i < doing.length; i++) {
    new item(doing[i], "doing");
  }
  for (var i = 0; i < done.length; i++) {
    new item(done[i], "done");
  }

  // *Supprimer la tâche

  $(".remove").click(function () {
    let list_item = $(this).parent().parent();
    let itemName = $(this)
      .parent()
      .parent()
      .children(".List_item_left")
      .children()[0].value;
    let Emplacement = $(this).parent().parent().parent()[0].id.toLowerCase();
    deleteItem(list_item, itemName, Emplacement);
  });

  //* Modifier la tâche

  $(".modifier").on("click", function () {
    let input = $(this)
      .parent()
      .parent()
      .children(".List_item_left")
      .children()[0];
    let itemName = input.value;
    let Emplacement = $(this).parent().parent().parent()[0].id.toLowerCase();
    edit(input, itemName, Emplacement);
  });

  //* Détecter si le mode sombre est activé sur l'appareil

  function detectColorScheme() {
    var theme = "light"; //Theme 'light' par défaut

    // On utilise le stockage local pour override les paramètres thèmes de l'OS

    if (localStorage.getItem("theme") == null) {
      localStorage.setItem("theme", "light");
    }

    if (localStorage.getItem("theme")) {
      if (localStorage.getItem("theme") == "dark") {
        var theme = "dark";
      }
    } else if (!window.matchMedia) {
      //La méthode matchMedia n'est pas supportée
      return false;
    } else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      //le paramètre thème de l'OS a détecté un mode sombre
      var theme = "dark";
    }

    //dark theme preferred, set document with a `data-theme` attribute
    // On utilise le thème sombre, on met l'attribut 'data-theme' au doc avec la valeur dark
    if (theme == "dark") {
      document.documentElement.setAttribute("data-theme", "dark");
    }
  }

  detectColorScheme();

  //On identifie l'élement de la page qui sert de switch
});
const toggleSwitch = $("#theme_btn");

// Fonction qui change le thème et change la variable du stockage local

//pre-check the dark-theme checkbox if dark-theme is set
if (document.documentElement.getAttribute("data-theme") == "dark") {
  toggleSwitch.addClass("dark");
  toggleSwitch.removeClass("light");
}
function switchTheme() {
  let LocalTheme = localStorage.getItem("theme");

  switch (LocalTheme) {
    case "light":
      localStorage.setItem("theme", "dark");
      document.documentElement.setAttribute("data-theme", "dark");
      toggleSwitch.addClass("dark");
      toggleSwitch.removeClass("light");
      break;
    case "dark":
      localStorage.setItem("theme", "light");
      document.documentElement.setAttribute("data-theme", "light");
      toggleSwitch.addClass("light");
      toggleSwitch.removeClass("dark");
      break;
  }
}
//* Supprimer la tâche des coockies de l'ordinateur

function DeleteFromStorage(itemName, Emplacement) {
  var type;
  switch (Emplacement) {
    case "todo":
      type = todo;
      break;
    case "doing":
      type = doing;
      break;
    case "done":
      type = done;
      break;
  }
  let index = type.indexOf(itemName);
  type.splice(index, 1);
  window.localStorage.setItem(Emplacement, JSON.stringify(type));
}

//* fonctions lorsqu'on dépose une tâche

var todoEX = window.localStorage.getItem("todo");
var todo = JSON.parse(todoEX);

var doingEX = window.localStorage.getItem("doing");
var doing = JSON.parse(doingEX);

var doneEX = window.localStorage.getItem("done");
var done = JSON.parse(doneEX);

function dragstart_handler(ev) {
  ev.dataTransfer.setData("text/html", ev.target.id);
  ev.dataTransfer.dropEffect = "move";
}

function dragover_handler(ev) {
  ev.preventDefault();
  ev.dataTransfer.dropEffect = "move";
}

function drop_handler(ev) {
  ev.preventDefault();
  const data = ev.dataTransfer.getData("text/html");
  const item = document.getElementById(data);
  let item_name = item.children[0].children[0].value;
  let type = item.parentNode.id.toLowerCase();
  if (
    ev.target.id == "TODO" ||
    ev.target.id == "DOING" ||
    ev.target.id == "DONE"
  ) {
    if (item.parentNode !== ev.target) {
      switch (ev.target.id) {
        case "TODO":
          todo.push(item_name);
          window.localStorage.setItem("todo", JSON.stringify(todo));
          break;

        case "DOING":
          doing.push(item_name);
          window.localStorage.setItem("doing", JSON.stringify(doing));
          break;

        case "DONE":
          done.push(item_name);
          window.localStorage.setItem("done", JSON.stringify(done));
          break;
      }
      DeleteFromStorage(item_name, type);
      ev.target.appendChild(item);
    }
  }
}

//* Modifier la tâche

function edit(input, itemName, Emplacement) {
  input.disabled = !input.disabled;

  input.focus();
  input.onkeydown = function (event) {
    if (event.keyCode == 13) {
      switch (Emplacement) {
        case "todo":
          var indexof = todo.indexOf(itemName);
          todo[indexof] = input.value;
          window.localStorage.setItem(Emplacement, JSON.stringify(todo));
          break;

        case "doing":
          var indexof = doing.indexOf(itemName);
          doing[indexof] = input.value;
          window.localStorage.setItem(Emplacement, JSON.stringify(doing));
          break;

        case "done":
          var indexof = done.indexOf(itemName);
          done[indexof] = input.value;
          window.localStorage.setItem(Emplacement, JSON.stringify(done));
          break;
      }
      input.disabled = true;
    }
  };
  input.onblur = function () {
    switch (Emplacement) {
      case "todo":
        var indexof = todo.indexOf(itemName);
        todo[indexof] = input.value;
        window.localStorage.setItem(Emplacement, JSON.stringify(todo));
        break;

      case "doing":
        var indexof = doing.indexOf(itemName);
        doing[indexof] = input.value;
        window.localStorage.setItem(Emplacement, JSON.stringify(doing));
        break;

      case "done":
        var indexof = done.indexOf(itemName);
        done[indexof] = input.value;
        window.localStorage.setItem(Emplacement, JSON.stringify(done));
        break;
    }
    input.disabled = true;
  };
}

//* Supprimer la tâche du doc

function deleteItem(list_item, itemName, Emplacement) {
  console.log("hey");
  var type;
  switch (Emplacement) {
    case "todo":
      type = todo;
      break;
    case "doing":
      type = doing;
      break;
    case "done":
      type = done;
      break;
  }
  let index = type.indexOf(itemName);
  type.splice(index, 1);
  window.localStorage.setItem(Emplacement, JSON.stringify(type));
  list_item.remove();
}

//* Fonctions qui sort un id unique pour les éléments.

function uniqid() {
  var ts = String(new Date().getTime()),
    out = "",
    In = Math.floor(Math.random() * Math.floor(1000000));
  for (i = 0; i < ts.length; i += 2) {
    out += Number(ts.substr(i, 2)).toString(36);
  }
  return In + "d" + out;
}
